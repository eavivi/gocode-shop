import './Products.css'
import Product from './Product'

function Products(){
    return(<section class="products">
        <Product/>    
    </section>

    );
}
export default Products;
